<?php

// Três variáveis do tipo float
$numero1 = 1.5;
$numero2 = 2.5;
$numero3 = 3.5;

// imprimindo
echo "Primeiro número: $numero1<br>";
echo "Segundo número: $numero2<br>";
echo "Terceiro número: $numero3<br><br>";

// verificação
if (is_float($numero1)) {
    echo "O primeiro número é um float.<br>";
}

if (is_float($numero2)) {
    echo "O segundo número é um float.<br>";
}

if (is_float($numero3)) {
    echo "O terceiro número é um float.<br><br>";
}

//aspas duplas
echo "Duas aspas hahaha<br>";

//aspas simples
echo 'Aspas simples hahahaha.<br>';

?>