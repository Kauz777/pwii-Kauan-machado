<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Teste PHP</title>
</head>
<body>

<?php

echo "PHP";

$a = 12.8;
$b = 6565.63;
$c = 3.14;

echo "<br>";
echo $a . "<br>";
echo $b . "<br>";
echo $c . "<br>";

?>

</body>
</html>
